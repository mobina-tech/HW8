#include<stdio.h>            // Mobina Teromideh   40223021
#include<stdlib.h>
struct time
{
    int min;
    int sec;
};
struct runner
{
    char firstName[20];
    char lastName[30];
    int ID;
    struct time *record;
    struct time runningTime;
    
};
int main()
{
    int n;


    printf("Enter numbers of people:");
    scanf("%d",&n);
    struct runner e[n];
    
    for(int i=0;i<n;i++)
    {
        scanf("%s%s",e[i].firstName,e[i].lastName);
        scanf("%d",&e[i].ID);
        e[i].record=(struct time*)malloc(sizeof(struct time));
        scanf("%d",&e[i].record->min);
        scanf("%d",&e[i].record->sec);
        scanf("%d%d",&e[i].runningTime.min,&e[i].runningTime.sec);
    }
    int winner=0;
    for(int j=1;j<n;j++)
    {
        if(e[j].runningTime.min < e[winner].runningTime.min ||
        ((e[j].runningTime.min == e[winner].runningTime.min)&&
        (e[j].runningTime.sec <e[winner].runningTime.sec)))
        {
            winner=j;
        }

    }
    printf("first name:%s\tlast name:%s",e[winner].firstName,e[winner].lastName);
    printf("\n");
    if(e[winner].runningTime.min <e[winner].record->min ||
    ((e[winner].runningTime.min==e[winner].record->min)&&
    e[winner].runningTime.sec < e[winner].record->sec))
    {
        printf("winner could break its own record");
    }
    else
    {
        printf("winner could not break its own record");
    }
    int flag=0;
    for(int k=0;k<n;k++)
    {
        if(k!=winner &&(e[winner].runningTime.min <e[k].record->min||
        (e[winner].runningTime.min ==e[k].record->min&&
        e[winner].runningTime.sec < e[k].record->sec)))
        {
            flag=1;
            break;
        }
        
        
    }
    if(flag)//winner has broken records of others
    {
        printf("\n winner breaks the best record of people\n");

    }
    else
    {
        printf("\n winner can't break the best record of people\n");
    }

    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            int y1=e[i].runningTime.min*60+e[i].runningTime.sec;//we have second
            int y2=e[j].runningTime.min*60+e[j].runningTime.sec;//we have second
            if(y1>y2)
            {
                struct runner temp=e[i];
                e[i]=e[j];
                e[j]=temp;
            }
        }

    }

    printf("%-20s%-20s","first name","last name");
    printf("%-10s%-20s%-20s","ID","record(min:sec)","running time(min:sec)");
    printf("\n");

    for(int i=0;i<n;i++)
    {
        printf("%-20s%-20s%-10d%-3d:%-8d\t\t%-3d:%-6d\n",e[i].firstName,e[i].lastName,
        e[i].ID,e[i].record->min,e[i].record->sec,
        e[i].runningTime.min,e[i].runningTime.sec);


        free(e[i].record);
    }


return 0;
}